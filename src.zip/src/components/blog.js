import React from 'react';
import writing_svg from '../assets/writing.svg';

import { Link } from 'react-router-dom'; 


function Blog() {
    return (
        <div id="blog" className="section-content blog-section">
            <div className='blog-container'>
                <div className='blog-content'>
                    <h1>Blog</h1>
                    <i> More blog posts will be uploaded soon! </i>
                    {/* link to the main blog page here */}
                    <Link to="/blog" className="blog-main-page-link"> Blog Page</Link>



                    <div className='blog-post-container'>
                        <a href="https://example.com/page1" target="_blank" rel="noopener noreferrer">
                            <div>1</div>
                        </a>
                        <a href="https://example.com/page2" target="_blank" rel="noopener noreferrer">
                            <div> 
                                <i> 
                                <    img src={writing_svg} alt="writing" className="writing" />
                                    on the way...
                                 </i>
                            </div>                        </a>
                        <a href="https://example.com/page3" target="_blank" rel="noopener noreferrer">
                            <div> 
                                <i> 
                                <    img src={writing_svg} alt="writing" className="writing" />
                                    on the way...
                                 </i>
                            </div>
                        </a>
                        <a href="https://example.com/page4" target="_blank" rel="noopener noreferrer">
                            <div> 
                                <i> 
                                <    img src={writing_svg} alt="writing" className="writing" />
                                    on the way...
                                 </i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Blog;

