import React from 'react';

function Footer() {
    return (
        <div id="footer" className="section-content footer-section">
            <div>Made with React, Node.js by @JuYoungYang </div>
        </div>
    );
}

export default Footer;
