import React from 'react';

function Footer() {
    return (
        <div id="footer" className="blog-footer">
            <div>Made with React, Node.js by @JuYoungYang </div>
        </div>
    );
}

export default Footer;
