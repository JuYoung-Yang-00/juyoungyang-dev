
# Title of Post 1

## Subtitle of Post 1

Category: Lifestyle | Date: 2024-03-01

![Image](https://via.placeholder.com/150)

Content of the second blog post. Similar to Post 1, this markdown file can include:

1. Numbered lists
2. Code blocks
3. Quotes
4. And more
