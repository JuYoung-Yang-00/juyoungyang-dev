// import React, { useState, useEffect } from 'react';
// import ReactMarkdown from 'react-markdown';
// import remarkGfm from 'remark-gfm';
// import { useParams } from 'react-router-dom';

// const BlogPostTemplate = () => {
//   const { postId } = useParams(); // Use the postId from the URL
//   const [postMetadata, setPostMetadata] = useState({
//     title: '',
//     subtitle: '',
//     category: '',
//     date: '',
//     imageSrc: '',
//   });
//   const [postContent, setPostContent] = useState('');

//   useEffect(() => {
//     fetch(`${process.env.PUBLIC_URL}/src/blog/posts/${postId}.md`)
//       .then(response => response.text())
//       .then(text => {
//         // Simple parsing logic for metadata
//         const lines = text.split('\n');
//         let metadata = {
//           title: '',
//           subtitle: '',
//           category: '',
//           date: '',
//           imageSrc: '',
//         };
//         let contentStartIndex = 0;

//         for (let i = 0; i < lines.length; i++) {
//           if (lines[i].startsWith('# ')) {
//             metadata.title = lines[i].substring(2).trim();
//           } else if (lines[i].startsWith('## ')) {
//             metadata.subtitle = lines[i].substring(3).trim();
//           } else if (lines[i].startsWith('Category: ')) {
//             const categoryDateLine = lines[i].split('|');
//             metadata.category = categoryDateLine[0].split(':')[1].trim();
//             metadata.date = categoryDateLine[1].split(':')[1].trim();
//           } else if (lines[i].startsWith('![')) {
//             metadata.imageSrc = lines[i].match(/\((.*?)\)/)[1];
//           } else if (!lines[i].startsWith('![') && lines[i].trim() !== '') {
//             contentStartIndex = i;
//             break;
//           }
//         }

//         // Set parsed metadata and content
//         setPostMetadata(metadata);
//         // The content is everything after the metadata lines
//         setPostContent(lines.slice(contentStartIndex).join('\n'));
//       })
//       .catch(err => console.error("Error fetching post:", err));
//   }, [postId]);

//   return (
//     <article>
//       <h1>{postMetadata.title}</h1>
//       <h2>{postMetadata.subtitle}</h2>
//       <div>{`${postMetadata.category} | Date: ${postMetadata.date}`}</div>
//       {postMetadata.imageSrc && <img src={postMetadata.imageSrc} alt="Post" />}
//       <ReactMarkdown children={postContent} remarkPlugins={[remarkGfm]} />
//     </article>
//   );
// };

// export default BlogPostTemplate;


import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useParams } from 'react-router-dom';

const BlogPostTemplate = () => {
  const { postId } = useParams(); // Use the postId from the URL
  const [postContent, setPostContent] = useState('');

  useEffect(() => {
    fetch(`${process.env.PUBLIC_URL}/posts/${postId}.md`)
      .then(response => response.text())
      .then(text => {
        // Set fetched content
        setPostContent(text);
      })
      .catch(err => console.error("Error fetching post:", err));
  }, [postId]);

  return (
    <article>
      <ReactMarkdown children={postContent} remarkPlugins={[remarkGfm]} />
    </article>
  );
};

export default BlogPostTemplate;
